# ReviewSense — Product Review Sentiment Analyzer

A polished Streamlit dashboard that uploads product-review CSV files, classifies reviews in batches of 20 using Gemini, displays sentiment analytics, and summarizes recurring complaints.

## Run

```bash
pip install -r requirements.txt
cp .env.example .env
# Add your Gemini API key to .env
streamlit run app.py
```

You can also enter your API key in the sidebar. Upload a CSV containing a review column (e.g. `review`, `review_text`, `text`, `content`). Select the column and click **Analyze reviews**. A sample CSV is included.

The app uses the Gemini API only when you click Analyze; your review text is sent to Gemini for processing. The included sample data is fictional.
